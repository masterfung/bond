"""
Django settings for bond project.

For more information on this file, see
https://docs.djangoproject.com/en/1.6/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.6/ref/settings/
"""

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os
import djcelery

SITE_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
#
# BASE_DIR = os.path.abspath(os.path.join(SITE_ROOT, ".."))
BASE_DIR = os.path.dirname(os.path.dirname(__file__))

# PROJECT_DIRECTORY = os.getcwd()

# os.environ['DJANGO_SETTINGS_MODULE'] = 'bond.settings'

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.6/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'p$c@7ea3!kb%-rc=q(tcezh#$g-r6gcpa=h^g(irmf9!4bj^_l'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

TEMPLATE_DEBUG = True

ALLOWED_HOSTS = []

# reCAPTCHA

RECAPTCHA_PUBLIC_KEY = '6LcALfcSAAAAANoHRi_vk0tnLW5mNW1AA8E-cXrH'
RECAPTCHA_PRIVATE_KEY = '6LcALfcSAAAAAF_7sa5lD1IF5U1J8n2Lp_orJxNn'

# Application definition

INSTALLED_APPS = (
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.sites',  # 'registration',
    'apps.profiles',
    'bcrypt',
    'social.apps.django_app.default',
    'apps.meetup',
    'crispy_forms',
    'floppyforms',
    'captcha',
    'scraper',
    'apps.events',
    'apps.eventbrite',
    'rest_framework',
    'djcelery',
    'djangular',
    'whoosh',
    'haystack',
    'herokuapp',
    'storages',
    'pytz',
    'dateutil',
    'tzlocal',
    'compressor',
    'django_coverage',
    'jasmine',
    'delorean',
    'oauth2_provider',
    'corsheaders',
    'opbeat.contrib.django',
    'debug_toolbar',
    'easy_timezones',
    'raven.contrib.django.raven_compat',
)

MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'easy_timezones.middleware.EasyTimezoneMiddleware',
    'corsheaders.middleware.CorsMiddleware',
)

RAVEN_CONFIG = {
    'dsn': 'https://1eae96827d564c5eb1aeb484246bea14:fbdd63920dda4331b880247239c60050@app.getsentry.com/29866',
}

ROOT_URLCONF = 'bond.urls'

WSGI_APPLICATION = 'bond.wsgi.application'

GEOIP_DATABASE = 'GeoLiteCity.dat'

CORS_ORIGIN_ALLOW_ALL = True

# MEETUP_API_KEY = '67f634b2a311c1b104c2c2e45d3856' #thu - main
# MEETUP_API_KEY = '4f3c20b51101b4825354a1c73584566' #mai
# MEETUP_API_KEY = '5c6e9493f45336362112954612a1563'  # uchi
MEETUP_API_KEY = '67500181f2c743b4f53297d2c453457'

EVENTBRITE_API_KEY = 'ZK2FA7QOSAKQ3UUKPC'

# EVENTBRITE_OAUTH_KEY = 'Y6NQUIILSJKGNHSHJ3CH' # bad one
EVENTBRITE_OAUTH_KEY = 'TAUK2INWUTBT7AUJSVZH'

# Database
# https://docs.djangoproject.com/en/1.6/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}

PASSWORD_HASHERS = (
    'django.contrib.auth.hashers.BCryptSHA256PasswordHasher',
    'django.contrib.auth.hashers.BCryptPasswordHasher',
    'django.contrib.auth.hashers.PBKDF2PasswordHasher',
    'django.contrib.auth.hashers.PBKDF2SHA1PasswordHasher',
    'django.contrib.auth.hashers.SHA1PasswordHasher',
    'django.contrib.auth.hashers.MD5PasswordHasher',
    'django.contrib.auth.hashers.CryptPasswordHasher',
)

TEMPLATE_CONTEXT_PROCESSORS = (
    "django.contrib.auth.context_processors.auth",
    "django.core.context_processors.debug",
    "django.core.context_processors.i18n",
    "django.core.context_processors.media",
    "django.core.context_processors.static",
    "django.core.context_processors.tz",
    "django.contrib.messages.context_processors.messages",

    "django.core.context_processors.request",
    'social.apps.django_app.context_processors.backends',
    'social.apps.django_app.context_processors.login_redirect',
)

# Rest Framework

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'oauth2_provider.ext.rest_framework.OAuth2Authentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    ),
    'DEFAULT_THROTTLE_CLASSES': (
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle'
    ),
    'DEFAULT_THROTTLE_RATES': {
        'anon': '100/day',
        'user': '1000/day'
    },
    'PAGINATE_BY': 10,  # Default to 10
    'PAGINATE_BY_PARAM': 'page_size',  # Allow client to override, using `?page_size=xxx`.
    'MAX_PAGINATE_BY': 100  # Maximum limit allowed when using `?page_size=xxx`.
}

# OAuth 2

OAUTH2_PROVIDER = {  # this is the list of available scopes
                     'SCOPES': {'read': 'Read scope', 'write': 'Write scope', 'groups': 'Access to your groups'}
}

# Social

AUTHENTICATION_BACKENDS = (

    'social.backends.open_id.OpenIdAuth',
    'social.backends.facebook.FacebookOAuth2',
    'social.backends.linkedin.LinkedinOAuth2',
    'social.backends.twitter.TwitterOAuth',
    "django.contrib.auth.backends.ModelBackend",
)

SOCIAL_AUTH_PIPELINE = (
    'social.pipeline.social_auth.social_details',
    'social.pipeline.social_auth.social_uid',
    'social.pipeline.social_auth.auth_allowed',
    'social.pipeline.social_auth.social_user',
    'social.pipeline.user.get_username',
    'social.pipeline.social_auth.associate_by_email',
    'social.pipeline.user.create_user',
    'social.pipeline.social_auth.associate_user',
    'social.pipeline.social_auth.load_extra_data',
    'social.pipeline.user.user_details',
    'apps.profiles.pipeline.user.save_profile',
)

SOCIAL_AUTH_DISCONNECT_PIPELINE = (
    'social.pipeline.disconnect.allowed_to_disconnect',
    'social.pipeline.disconnect.get_entries',
    'social.pipeline.disconnect.revoke_tokens',
    'social.pipeline.disconnect.disconnect',
)

# USER_FIELDS = ['username', 'email', 'first_name', 'last_name', 'phone', 'city', 'age', 'picture_url', 'provider']
SOCIAL_AUTH_PROTECTED_USER_FIELDS = ['email', ]
SOCIAL_AUTH_USERNAME_IS_FULL_EMAIL = True

# Facebook
SOCIAL_AUTH_FACEBOOK_KEY = '1396569227270598'
SOCIAL_AUTH_FACEBOOK_SECRET = 'b2ff437fd61c8b89f34fed88c9e8d0a8'
SOCIAL_AUTH_FACEBOOK_SCOPE = ['user_likes', 'email', 'user_location', 'publish_actions', 'user_birthday',
                              'user_activities', 'user_groups', 'user_interests', 'user_events', 'user_work_history',
                              'friends_location', 'friends_interests', ]
SOCIAL_AUTH_FACEBOOK_PROFILE_EXTRA_PARAMS = {'locale': 'ru_RU'}

# Celery
djcelery.setup_loader()

BROKER_URL = 'redis://localhost:6379/0'

CELERY_RESULT_BACKEND = 'redis://localhost:6379/0'
BROKER_TRANSPORT = 'redis'
CELERYBEAT_SCHEDULER = 'djcelery.schedulers.DatabaseScheduler'

# WHOOSH

WHOOSH_INDEX = os.path.join(SITE_ROOT, 'whoosh/')

# HAYSTACK

HAYSTACK_CONNECTIONS = {'default': {
    'ENGINE': 'haystack.backends.elasticsearch_backend.ElasticsearchSearchEngine',
    'URL': 'http://127.0.0.1:9200/',
    'INDEX_NAME': 'haystack',
    'INCLUDE_SPELLING': True,
    },
    'autocomplete': {
        'ENGINE': 'haystack.backends.elasticsearch_backend.ElasticsearchSearchEngine',
        'URL': 'http://127.0.0.1:9200/',
        'INDEX_NAME': 'hs_autocomplete',
    },  # 'default': {  # 'ENGINE': 'haystack.backends.whoosh_backend.WhooshEngine',
    # 'PATH': WHOOSH_INDEX,  # },
    }

# HAYSTACK_LIMIT_TO_REGISTERED_MODELS = False

HAYSTACK_SIGNAL_PROCESSOR = 'haystack.signals.RealtimeSignalProcessor'

# Internationalization
# https://docs.djangoproject.com/en/1.6/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_L10N = True

USE_TZ = True

SITE_ID = 1

TEST_RUNNER = 'django.test.runner.DiscoverRunner'

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.6/howto/static-files/

STATIC_URL = '/static/'

MEDIA_URL = '/media/'

TEMPLATE_DIRS = (
    os.path.join(SITE_ROOT, "templates"),
)

STATICFILES_DIRS = (
    os.path.join(BASE_DIR, "static", "static"),
)

MEDIA_ROOT = os.path.join(BASE_DIR, 'static', 'media')

AUTH_USER_MODEL = 'profiles.Profile'

LOGIN_REDIRECT_URL = 'profile'

LOGIN_URL = '/login/'

# Scrapy

os.environ['SCRAPY_SETTINGS_MODULE'] = 'scraper.settings'

# Compressor Settings

# COMPRESS_ENABLED = True

COMPRESS_ROOT = os.path.join(BASE_DIR, "static")

COMPRESS_CSS_FILTERS = ['compressor.filters.cssmin.CSSMinFilter']

STATICFILES_FINDERS = (
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
    'compressor.finders.CompressorFinder',
)

# Email settings.

EMAIL_HOST = "smtp.sendgrid.net"

EMAIL_HOST_USER = os.environ.get("SENDGRID_USERNAME")

EMAIL_HOST_PASSWORD = os.environ.get("SENDGRID_PASSWORD")

EMAIL_PORT = 587

EMAIL_USE_TLS = True

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'filters': {
        'require_debug_false': {
            '()': 'django.utils.log.RequireDebugFalse'
        }
    },
    'handlers': {
        'mail_admins': {
            'level': 'ERROR',
            'filters': ['require_debug_false'],
            'class': 'django.utils.log.AdminEmailHandler'
        }
    },
    'loggers': {
        'django.request': {
            'handlers': ['mail_admins'],
            'level': 'ERROR',
            'propagate': True,
        },
    }
}

try:
    from local_settings import *
except ImportError:
    pass
