function indexController($scope) {
	return '../views/survey.html'
}