/**
 * Created by htm on 8/11/14.
 */
function startSurveyController($scope) {
//	return '../views/getting-started.html'
}