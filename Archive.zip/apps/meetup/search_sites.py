__author__ = 'htm'

import haystack

haystack.autodiscover()