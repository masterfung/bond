__author__ = 'htm'

# from haystack.forms import SearchForm
#
# class EventIndexForm(SearchForm):
#
#     def no_query_found(self):
#         return self.searchqueryset.all()