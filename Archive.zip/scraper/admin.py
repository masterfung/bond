from django.contrib import admin

# Register your models here.
from scraper.models import Scraper


admin.site.register(Scraper)